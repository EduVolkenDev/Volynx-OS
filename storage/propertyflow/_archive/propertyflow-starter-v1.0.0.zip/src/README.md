# Source placeholder

This package includes the final tier documentation, license, environment shape, public assets and build contract. Drop the generated React + Vite source for the Starter tier here before public delivery.

Expected Starter scope: static JSON catalogue, filters, EN/PT interface, responsive layouts and 3 grid templates.
