# Source placeholder

This package includes the final tier documentation, license, environment shape, public assets and build contract. Drop the generated React + Vite source for the Professional tier here before public delivery.

Expected Professional scope: Starter plus Supabase, admin dashboard, enquiries, image gallery/modals and 6 grid templates.
