# Admin placeholder

Add Professional admin dashboard source here: properties CRUD, leads inbox, featured toggles and image upload.
