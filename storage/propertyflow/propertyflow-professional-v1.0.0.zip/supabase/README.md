# Supabase placeholder

Add migrations, seed data, storage buckets and RLS policies here. See docs/SUPABASE.md for the required production setup.
