# Supabase placeholder

Add tenant-aware migrations, seed data, storage buckets and RLS policies here. See docs/SUPABASE.md and docs/MULTI_TENANT.md.
