# Template placeholders

Expected 15 templates: classic, magazine, compact, gallery-hero, split-view, masonry, editorial, minimalist, card-stack, timeline, map-first, grouped, story-mode, showroom, catalog.
