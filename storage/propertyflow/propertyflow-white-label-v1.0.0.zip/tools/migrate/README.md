# Migration toolkit placeholder

Add importers for CSV, DOMUS/VivaReal, ZAP, Aglow and generic spreadsheet sources. See docs/MIGRATION_TOOLKIT.md.
